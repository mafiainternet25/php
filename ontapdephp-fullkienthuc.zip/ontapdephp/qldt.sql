CREATE TABLE detai (
    madt INT AUTO_INCREMENT PRIMARY KEY,
    tendt VARCHAR(30)
);

CREATE TABLE giangvien (
    magv INT AUTO_INCREMENT PRIMARY KEY,
    hoten VARCHAR(30),
    dienthoai VARCHAR(15),
    ghichu VARCHAR(30)
);

CREATE TABLE sinhvien (
    masv VARCHAR(5) PRIMARY KEY,
    hoten VARCHAR(30),
    ngaysinh VARCHAR(15),
    madt INT,
    magv INT,
    FOREIGN KEY (madt) REFERENCES detai(madt),
    FOREIGN KEY (magv) REFERENCES giangvien(magv)
);

INSERT INTO detai (tendt) VALUES ('Web ban hang'), ('Quan ly thu vien'), ('Nhan dien khuon mat');
INSERT INTO giangvien (hoten, dienthoai, ghichu) VALUES ('Nguyen Van A', '0912345678', 'Tot'), ('Tran Thi B', '0987654321', 'Kha'), ('Le Van C', '0909090909', 'Gioi');
INSERT INTO sinhvien (masv, hoten, ngaysinh, madt, magv) VALUES ('SV01', 'Em SV A', '2003-01-01', 1, 1), ('SV02', 'Em SV B', '2003-02-02', 2, 2), ('SV03', 'Em SV C', '2003-03-03', 3, 3);