<?php
    include 'Header.php'; 
    include 'Menu.php'; 
    echo"gioi thieu nganh cntt dai hoc vinh";echo"<br>";
    echo'<a href="../cau1/hienthigv.php">Câu 1b</a>';echo"<br>";
    echo'<a href="../cau1/themgv.php">Câu 1c</a>';echo"<br>";
    echo'<a href="../cau1/timgv.php">Câu 1d</a>';echo"<br>";
    echo'<a href="../cau1/tonghop.php">Câu 1e</a>';echo"<br>";
    echo'<a href="../cau1/xoasv.php">Câu 1f</a>';echo"<br>";
    echo'<a href="../cau1/suasv.php">Câu 1g</a>';echo"<br>";
    echo'<a href="../cau2/login.html">Câu 2</a>';echo"<br>";
    echo'<a href="../cau4/login.html">Câu 4</a>';echo"<br>";
    include 'Footer.php';
?>
