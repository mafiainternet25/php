<?php 
    echo date("d/m/Y H:i:s");echo"<br>";
    echo "25 Năm Truyền thống ngành Công nghệ thông tin – Trường Đại học Vinh (1998-2023)";
    echo"<br>";
?>