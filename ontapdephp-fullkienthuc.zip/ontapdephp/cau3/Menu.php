<?php
    echo'<a href="#">trang chu</a>';echo"<br>";
    echo'<a href="#">tin tuc</a>';echo"<br>";
    echo'<a href="#">lich tuan</a>';echo"<br>";
    echo'<a href="#">van ban</a>';echo"<br>";
    echo'<a href="#">huong nghiep</a>';echo"<br>";
?>