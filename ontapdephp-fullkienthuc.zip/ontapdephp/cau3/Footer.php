<?php
    echo "Viện Kỹ thuật và Công nghệ, Trường Đại học Vinh – Tầng 1, Nhà A0, 182 Lê Duẩn, TP Vinh, Nghệ An";
?>