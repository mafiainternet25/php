<?php
    session_start();
    session_unset();
    session_destroy();
    echo"da xoa session";
    echo'<a href="login.html">login</a>';
?>