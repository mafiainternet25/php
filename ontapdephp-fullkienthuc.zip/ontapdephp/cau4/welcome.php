<?php
    session_start();
    $user = $_POST['user'];
    $password = $_POST['password'];
    $_SESSION['user'] = $user;
    echo"chao mung " .$_SESSION['user'];
    echo'<a href="clearsession.php">logout</a>';
?>