
<form method="post">   
    masv:<input type="text" name="masv" required><br>
    <input type="submit" name="xoa" value="xoa">
</form>

<?php 
    include 'connect.php';
    $masv = $_POST['masv'];
    if(isset($_POST['xoa'])){
        $sqlxoa = "DELETE FROM sinhvien WHERE  masv = '$masv'";
        $ketquaxoa = mysqli_query($conn,$sqlxoa);
    }
?>
 

