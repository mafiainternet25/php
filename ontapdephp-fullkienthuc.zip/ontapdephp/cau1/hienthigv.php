<?php
    include 'connect.php';
    $sql = "SELECT * FROM giangvien";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        echo "-" .$row['magv'];
        echo "-" .$row['hoten'];
        echo "-" .$row['dienthoai'];
        echo "-" .$row['ghichu'];
        echo "<br>";
    }
?>
