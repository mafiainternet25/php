<?php
    include 'connect.php';
    $sql = "SELECT s.hoten as tensv, d.tendt, g.hoten as tengv 
            FROM sinhvien s 
            JOIN detai d ON s.madt = d.madt 
            JOIN giangvien g ON s.magv = g.magv";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        echo "-" . $row['tensv'];
        echo "-" . $row['tendt'];
        echo "-" . $row['tengv'];
        echo "<br>";
    }
?>
