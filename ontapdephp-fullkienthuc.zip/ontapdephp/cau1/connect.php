<?php
    $conn = mysqli_connect("localhost", "root", "", "qldt");
    if (!$conn) die("Lỗi kết nối: " . mysqli_connect_error());
?>