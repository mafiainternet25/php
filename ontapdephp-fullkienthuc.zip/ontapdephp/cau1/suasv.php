<?php 
    include 'connect.php';

    $sql = "SELECT * FROM sinhvien";
    $ketqua = mysqli_query($conn, $sql);
    while($duyet = mysqli_fetch_assoc($ketqua)){
        echo "-" . $duyet['masv'];
        echo "-" . $duyet['hoten'];
        echo "-" . $duyet['ngaysinh'];
        echo "-" . $duyet['madt'];
        echo "-" . $duyet['magv'];
        echo "<a href='suasv.php?masv=" . $duyet['masv'] . "'>sua</a>";
        echo "<br>";
    }

    echo "<br>";

    if(isset($_GET['masv'])){
        $masv = $_GET['masv'];
        $sqlget = "SELECT * FROM sinhvien WHERE masv = '$masv'";
        $kqget = mysqli_query($conn, $sqlget);
        $duyetget = mysqli_fetch_assoc($kqget);
        if($duyetget){
            $hoten = $duyetget['hoten'];
            $ngaysinh = $duyetget['ngaysinh'];
            $madt = $duyetget['madt'];
            $magv = $duyetget['magv'];
        }
    }

    if(isset($_POST['sua'])){
        $hotenmoi = $_POST['hoten'];
        $ngaysinhmoi = $_POST['ngaysinh'];
        $madtmoi = $_POST['madt'];
        $magvmoi = $_POST['magv'];
        $sqlsua = "UPDATE sinhvien SET hoten = '$hotenmoi',ngaysinh = '$ngaysinhmoi',madt = '$madtmoi',magv = '$magvmoi' WHERE masv = '$masv'";
        if(mysqli_query($conn, $sqlsua)){
            $hoten = $hotenmoi; 
            $ngaysinh = $ngaysinhmoi; 
            $madt = $madtmoi; 
            $magv = $magvmoi;
        }
    }
?>

<form method="post">   
    masv: <input type="text" name="masv" value="<?php echo $masv; ?>" readonly><br>
    hoten: <input type="text" name="hoten" value="<?php echo $hoten; ?>"><br>
    ngaysinh: <input type="text" name="ngaysinh" value="<?php echo $ngaysinh; ?>"><br>
    madt: <input type="text" name="madt" value="<?php echo $madt; ?>"><br>
    magv: <input type="text" name="magv" value="<?php echo $magv; ?>"><br>
    <input type="submit" name="sua" value="sua">
</form>
