<?php
    include 'connect.php'; 
    if (isset($_POST['them'])) {
        $magv = $_POST['magv'];
        $hoten = $_POST['hoten'];
        $dienthoai = $_POST['dienthoai'];
        $ghichu = $_POST['ghichu'];
        $sql = "INSERT INTO giangvien (magv, hoten, dienthoai, ghichu) VALUES ('$magv', '$hoten', '$dienthoai', '$ghichu')";
        mysqli_query($conn, $sql);
    }
?>

<form method="post">
    Mã GV: <input type="text" name="magv"><br>
    Tên: <input type="text" name="hoten"><br>
    SĐT: <input type="text" name="dienthoai"><br>
    Ghi chú: <input type="text" name="ghichu"><br>
    <input type="submit" name="them" value="Thêm">
</form>