<form method="post">
    Nhập tên GV: <input type="text" name="ten"><br> 
    <input type="submit" value="Tìm">
</form>

<?php
    include 'connect.php';
    if (isset($_POST['ten'])) {
        $ten = $_POST['ten'];
        $result = mysqli_query($conn, "SELECT * FROM giangvien WHERE hoten LIKE '%$ten%'");
        while ($row = mysqli_fetch_assoc($result)) {
            echo "-" . $row['hoten'];
            echo "-" . $row['dienthoai'];
            echo "<br>";
        }
    }
?>