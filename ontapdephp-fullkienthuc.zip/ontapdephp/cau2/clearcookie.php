<?php
setcookie("username", "", time() - 36);
echo "Đã xóa cookie. <a href='login.html'>Login</a>";
?>