<?php 
    $user = $_POST['user'];
    $password = $_POST['password'];
    setcookie("user",$user,time()+36);
    echo"chao mung :" .$user;echo"<br>";
    echo'<a href="clearcookie.php">logout</a>';
?>